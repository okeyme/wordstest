Page({
	data: {
			inviteCode: '',
			isLoading: false
	},
	
	onLoad: function(options) {
			// 获取URL中的邀请码参数
			if (options.invite_code) {
					this.setData({
							inviteCode: options.invite_code
					});
					
					// 存储到全局数据中，以便登录时使用
					getApp().globalData.inviteCode = options.invite_code;
			}
			
			// 检查是否已经登录
			if (getApp().globalData.token) {
					wx.navigateBack();
			}
	},
	
	onGetUserInfo: function(e) {
			const that = this;
			const app = getApp();
			
			if (e.detail.userInfo) {
					// 用户同意授权
					this.setData({
							isLoading: true
					});
					
					// 调用App中的登录方法
					app.userLogin({
							success: function() {
									that.setData({
											isLoading: false
									});
									
									// 登录成功，跳转回原页面或首页
									wx.navigateBack();
							},
							fail: function(err) {
									that.setData({
											isLoading: false
									});
									
									wx.showToast({
											title: '登录失败：' + (err.message || err.errMsg),
											icon: 'none'
									});
							}
					}, app.globalData.inviteCode);
			} else {
					// 用户拒绝授权
					wx.showToast({
							title: '您拒绝了登录授权',
							icon: 'none'
					});
			}
	}
});