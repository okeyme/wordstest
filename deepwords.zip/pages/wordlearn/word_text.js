const app = getApp();
const wxc = app.globalData.wxc;
const webAudio = wx.createInnerAudioContext({
	useWebAudioImplement: true
});
const util = require('../../utils/util.js');
var timer = null;
Page({

    /**
     * 页面的初始数据
     */
    data: {
			headerName: '看词择义',
			serverHost: 'https://bossbell.com/miniprogram/',
			scrollHeight: '200px',
			scrollTop: 0,
			cid:null,
			dataArr:'',
			cateArr:[],
			Wordlist: [],
			wordKeyList: [],
			wordArr:[],
			disturArr:[],
			audioIndex:-1,
			wordCurrect:0,
			wordCount:0,
			correctCount:0,
			correctWordid:0,
			correctRate:0,
			selectWordID:0,
			wordclickActive:false,
			wordEnd: false,
			mytimeNow: Date.now(),
			mytimestamp:'--',
			activeItem:-1,
			errorWordArr:[],
			starsArr:[1,2,3,4,5],
			stars:0
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
			var that = this;
			this.data.cid = options.cid;
			const TokenStatus = setInterval(()=>{
				if(app.globalData.token!=''){
					clearInterval(TokenStatus);
					that.checkWordlist();
				}
			},100)
		},
		chooseAnswer: function(e){
			var that = this;
			if(this.data.wordclickActive) return;
			let wordid = e.currentTarget.dataset.wordid;
			let correctWordid = this.data.wordArr[this.data.wordCurrect].word_id;
			let errorWordArr = this.data.errorWordArr;
			this.data.wordclickActive = true;
			if(wordid == correctWordid){
				this.data.correctCount = this.data.correctCount+1;
				this.playStatus('correct');
				errorWordArr[this.data.wordCurrect] = '';
			}else{
				errorWordArr[this.data.wordCurrect] = this.data.wordCurrect;
				this.playStatus('wrong');
			}
			this.data.errorWordArr = errorWordArr;
			this.setData({selectWordID: wordid, correctWordid:correctWordid,correctCount:this.data.correctCount});
			timer = setTimeout(function(){
				that.nextWord();
			},2000);
		},
		nextWord: function(){
			let wordCurrect = this.data.wordCurrect;
			if(wordCurrect>=this.data.wordCount-1){
				this.showResult();
			}else{
				let mytimeNow = this.data.mytimeNow;
				let now = Date.now();
				let mytimestamp = util.getTimeDifference(mytimeNow,now);
				wordCurrect = wordCurrect+1;
				this.setData({wordCurrect: wordCurrect, selectWordID:0, mytimestamp:mytimestamp});
				this.disturbWords();
			}
			this.data.wordclickActive = false;
		},
		showResult: function(){
			let correctRate = Math.ceil(this.data.correctCount/this.data.wordCount * 100);
			let stars = Math.floor(this.data.correctCount/this.data.wordCount * 5);
			this.setData({ errorWordArr: this.data.errorWordArr,wordEnd:true,correctRate:correctRate,stars:stars});
			if(correctRate>70){
				this.playStatus('winner');
			}else if(correctRate>=50 && correctRate<=70){
				this.playStatus('nuli');
			}else{
				this.playStatus('loser');
			}
		},
		wordAudio: function(e){
			let index = e.currentTarget.dataset.index;
			this.data.wordCurrect = index;
			this.setData({ audioIndex: index});
			this.audioPlay();
		},
		audioPlay: function () {
			var that = this;
			let src = this.data.wordArr[this.data.wordCurrect].audio;
			src = "https://bossbell.com/"+src;
      webAudio.src = src;
			webAudio.play();
      webAudio.onPlay(()=>{
				console.log('音频开始播放');
      })
      webAudio.onEnded(()=>{
				console.log('音频播放完毕');
				that.setData({ audioIndex:-1});
      })
		},
		playStatus: function(st){
			let src = "https://bossbell.com/public/"+st+".mp3";
			webAudio.src = src;
			webAudio.play();
		},
		filterWordList: function(){
			var Wordlist = this.data.Wordlist;
			let cid = this.data.cid;
			if (Wordlist.hasOwnProperty(cid)) {
				var cateArr = Wordlist[cid]; //当前单元
				this.data.cateArr = cateArr;
				let idlist = cateArr['idlist'];
				if(idlist=='') return;
				var wordKeyList = Object.keys(Wordlist['list']);
				let idlistarr = idlist.split(",");
				var cc = 10;
				if(idlistarr.length>=10){
					cc = 10;
				}else{
					cc = idlistarr.length;
				}
				//随机取10个
				var keyarr = util.getRandomElements(idlistarr,cc);
				var arr = [];
				for(let key in keyarr){
					let obj = Wordlist['list'][keyarr[key]];
					let translate = obj.translate;
					translate = translate.replace(/\|/g, " ");
					translate = translate.replace(/#/g, " ");
					obj.translate = translate;
					arr[key] = obj;
					let index = wordKeyList.indexOf(keyarr[key]);
					if(index>-1){
						wordKeyList.splice(index, 1);
					}
				}
				this.data.wordKeyList = wordKeyList;
				this.setData({wordArr:arr,wordCount:cc});
				console.log('wordArr',arr);
				console.log(wordKeyList);
				this.disturbWords();
			}
		},
		disturbWords: function(){
			var Wordlist = this.data.Wordlist;
			let wordKeyList = this.data.wordKeyList;
			let keyarr = util.getRandomElements(wordKeyList,3);
			let wordArr = this.data.wordArr;
			var arr = [];
			for(let key in keyarr){
				let obj = Wordlist['list'][keyarr[key]];
				let translate = obj.translate;
				translate = translate.replace(/\|/g, " ");
				translate = translate.replace(/#/g, " ");
				obj.translate = translate;
				arr[key] = obj;
			}
			arr.push(wordArr[this.data.wordCurrect]);
			arr = util.shuffleArray(arr);
			this.setData({disturArr:arr});
		},
		checkWordlist: function(){
			var that = this;
		//查有没有缓存 token, 缓存可能被清空
			wxc.get('Wordlist').then(res=>{
				let dataArr = res;
				that.data.dataArr = dataArr;
				that.getWordlist(dataArr.version);
			}).catch(err=>{
				that.getWordlist();
			});
		},
		getWordlist: function(versionNumber=''){
			var that = this;
			app.requestHttp({ac:'getallwordlist',vg_id:app.globalData.vg_id,versionNumber:versionNumber}).then(res=>{
				if (res.data.code == 20000){
					var dataArr = that.data.dataArr;
					that.data.Wordlist = dataArr.data;
					that.filterWordList();
				}else if(res.data.code == 10000){
					let dataArr = res.data.data;
					wxc.set('Wordlist',dataArr);
					that.data.Wordlist = dataArr.data;
					that.filterWordList();
				}else{
					console.log("Wordlist获取失败");
				}
			}).catch(err=>{
				console.log("Wordlist获取失败");
			})
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (options) {
			// 返回分享的内容
			return {
				title: this.data.cateArr['category_name'],
				path: '/pages/index/index',
				imageUrl: '' // 分享卡片的图片，可选
			};
		},
		btnShare: function () {
			// 显示分享按钮
			wx.showShareMenu({
				withShareTicket: true
			});
		}
})