// pages/wordlearn/translate_spell.js
const app = getApp();
const wxc = app.globalData.wxc;
const webAudio = wx.createInnerAudioContext({
	useWebAudioImplement: true
});
const util = require('../../utils/util.js');
var timer = null;
Page({

    /**
     * 页面的初始数据
     */
    data: {
			headerName: '听音拼词',
			serverHost: 'https://bossbell.com/miniprogram/',
			scrollHeight: '200px',
			scrollTop: 0,
			cid:null,
			cateArr:[],
			Wordlist: [],
			wordKeyList: [],
			dataArr:'',
			wordArr:[],
			audioIndex:-1,
			webAudioStatus: false,
			wordCurrect:0,
			wordCount:0,
			correctCount:0,
			correctWordid:0,
			correctRate:0,
			wordEnd: false,
			mytimeNow: Date.now(),
			mytimestamp:'--',
			activeItem:-1,
			errorWordArr:[],
			starsArr:[1,2,3,4,5],
			stars:0,
			translate:'',
			wordShowClass:'',
			myEnterWord: '',
			wordCapital: false,
			clickLetter: '',
			timerCount:6,
			buttonTxt: '下一个',
			correctStatus:-1,
			showResult: false,
			errorWordArr:[],
			activeItem:0,
			check:false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
			this.data.cid = options.cid;
			var that = this;
			const TokenStatus = setInterval(()=>{
				if(app.globalData.token!=''){
					clearInterval(TokenStatus);
					that.checkWordlist();
				}
			},100)
		},
		check: function(){
			clearInterval(timer); 
			var that = this;
			var wordArr = this.data.wordArr;
			var errorWordArr = this.data.errorWordArr;
			let wordCurrect = this.data.wordCurrect;
			let correctWord = wordArr[wordCurrect].word;
			if(correctWord==this.data.myEnterWord){
				that.setData({check:true,correctCount:that.data.correctCount+1,correctStatus:1,translate:'正确',wordShowClass:'text-green'});
				errorWordArr[wordCurrect] = '';
				this.playStatus('correct');
			}else{
				that.setData({check:true,translate:'正确答案：'+wordArr[wordCurrect].word, correctStatus:0,wordShowClass:'text-red'});
				errorWordArr[wordCurrect] = this.data.myEnterWord; //记录错误答案
				this.playStatus('wrong');
			}
			timer = setInterval(() => {
				if(that.data.timerCount==1){
					this.nextWord();
				}else{
					that.data.timerCount = that.data.timerCount-1;
					that.setData({ buttonTxt:'('+that.data.timerCount+')下一个'});
				}
			},1000)
	},
		showWord: function(){
			var that = this;
			var wordArr = this.data.wordArr;
			let wordCurrect = this.data.wordCurrect;
			let word = wordArr[wordCurrect].word;
			console.log('word=',word);
			word = word.replace(/\s*/g,''); 
			let wordLetters = word.split(''); //打散为字母
			wordLetters = wordLetters.map(function(item) {
				return item.toLowerCase();
			});
			var LettersArr = Array.from(new Set(wordLetters));  //去重
			var abcArr=['b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'];
			var fixabc=['a','e','i','u','o'];
			var LettersArr2 = LettersArr.filter(item => !fixabc.includes(item)); //取差集
			//console.log(LettersArr2);
			var letters = LettersArr2;
			let LetterCount = LettersArr2.length;
			if(LetterCount<10){
				var abcArr2 = abcArr.filter(item => !LettersArr2.includes(item)); //取差集
			//	console.log(abcArr2);
				let addAbcArr = util.getRandomElements(abcArr2,10-LetterCount);
				var LettersArr3 = LettersArr2.concat(addAbcArr);
				letters = LettersArr3;
			}
			letters = util.shuffleArray(letters); //打乱
			that.setData({letters:letters});
			this.audioPlay();
		},
		nextWord: function(){
			clearInterval(timer); 
			let wordCurrect = this.data.wordCurrect;
			if(wordCurrect+1==this.data.wordCount){
				this.showResult();
			}else{
				wordCurrect = wordCurrect+1;
				let mytimeNow = this.data.mytimeNow;
				let now = Date.now();
				let mytimestamp = util.getTimeDifference(mytimeNow,now);
				this.setData({check:false,wordCurrect:wordCurrect,buttonTxt:'下一个',timerCount:6,myEnterWord:'',correctStatus:-1,mytimestamp:mytimestamp,wordShowClass:'',translate:''});
				this.showWord();
			}
		},
		showResult: function(){
			let correctRate = Math.ceil(this.data.correctCount/this.data.wordCount * 100);
			let stars = Math.floor(this.data.correctCount/this.data.wordCount * 5);
			this.setData({ errorWordArr: this.data.errorWordArr,wordEnd:true,correctRate:correctRate,stars:stars});
			if(correctRate>70){
				this.playStatus('winner');
			}else if(correctRate>=50 && correctRate<=70){
				this.playStatus('nuli');
			}else{
				this.playStatus('loser');
			}
		},
		wordAudio: function(e){
			let index = e.currentTarget.dataset.index;
			this.data.wordCurrect = index;
			this.audioPlay();
			this.setData({ audioIndex: index});
		},
		audioPlay: function () {
			var that = this;
			let src = this.data.wordArr[this.data.wordCurrect].audio;
			src = "https://bossbell.com/"+src;
      webAudio.src = src;
			webAudio.play();
			this.setData({webAudioStatus: true});
      webAudio.onPlay(()=>{
				console.log('音频开始播放');
      })
      webAudio.onEnded(()=>{
				console.log('音频播放完毕');
				that.setData({ audioIndex:-1,webAudioStatus:false});
      })
		},
		playStatus: function(st){
			let src = "https://bossbell.com/public/"+st+".mp3";
			webAudio.src = src;
			webAudio.play();
		},
		deleteLetter: function(){
			var letterWord = this.data.myEnterWord;
			if(letterWord.length>0){
				letterWord = letterWord.substring(0, letterWord.length-1);
				this.setData({ myEnterWord: letterWord});
			}
		},
		handleTouchStart: function(e){
			clearTimeout(timer);
			var that = this;
			var obj = e.currentTarget.dataset;
			var letter = obj.letter;
			var letterWord = this.data.myEnterWord;
			if(letter=='大写'){
				this.setData({ wordCapital: !this.data.wordCapital});
			}else if(letter=='句点'){
				letterWord=letterWord+'.';
			}else if(letter=='中横'){
				letterWord=letterWord+'-';
			}else if(letter=='上撇'){
				letterWord=letterWord+"'";
			}else if(letter=='空格'){
				letterWord=letterWord+' ';
			}else{
				if(this.data.wordCapital){
					letter = letter.toUpperCase();
					this.setData({ wordCapital: !this.data.wordCapital});
				}
				letterWord = letterWord+letter;
			}
			if(letter!='大写'){
				this.setData({ myEnterWord: letterWord,clickLetter:letter});
			}
		},
		handleTouchEnd: function(){
			this.timer = setTimeout(() => {
				this.setData({ clickLetter: ''});
			},500);
		},
		filterWordList: function(){
			var Wordlist = this.data.Wordlist;
			let cid = this.data.cid;
			if (Wordlist.hasOwnProperty(cid)) {
				var cateArr = Wordlist[cid]; //当前单元
				this.data.cateArr = cateArr;
				let idlist = cateArr['idlist'];
				if(idlist=='') return;
				var wordKeyList = Object.keys(Wordlist['list']);
				let idlistarr = idlist.split(",");
				var cc = 10;
				if(idlistarr.length>=10){
					cc = 10;
				}else{
					cc = idlistarr.length;
				}
				//随机取10个
				var keyarr = util.getRandomElements(idlistarr,cc);
				var arr = [];
				for(let key in keyarr){
					let obj = Wordlist['list'][keyarr[key]];
					let translate = obj.translate;
					translate = translate.replace(/\|/g, " ");
					translate = translate.replace(/#/g, " ");
					obj.translate = translate;
					arr[key] = obj;
					let index = wordKeyList.indexOf(keyarr[key]);
					if(index>-1){
						wordKeyList.splice(index, 1);
					}
				}
				this.data.wordKeyList = wordKeyList;
				this.setData({wordArr:arr,wordCount:cc});
				console.log('wordArr',arr);
				console.log(wordKeyList);
				this.showWord();
			}
		},
		checkWordlist: function(){
			var that = this;
		//查有没有缓存 token, 缓存可能被清空
			wxc.get('Wordlist').then(res=>{
				let dataArr = res;
				that.data.dataArr = dataArr;
				that.getWordlist(dataArr.version);
			}).catch(err=>{
				that.getWordlist();
			});
		},
		getWordlist: function(versionNumber=''){
			var that = this;
			app.requestHttp({ac:'getallwordlist',vg_id:app.globalData.vg_id,versionNumber:versionNumber}).then(res=>{
				if (res.data.code == 20000){
					var dataArr = that.data.dataArr;
					that.data.Wordlist = dataArr.data;
					that.filterWordList();
				}else if(res.data.code == 10000){
					let dataArr = res.data.data;
					wxc.set('Wordlist',dataArr);
					that.data.Wordlist = dataArr.data;
					that.filterWordList();
				}else{
					console.log("Wordlist获取失败");
				}
			}).catch(err=>{
				console.log("Wordlist获取失败");
			})
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (options) {
			// 返回分享的内容
			return {
				title: this.data.cateArr['category_name'],
				path: '/pages/index/index',
				imageUrl: '' // 分享卡片的图片，可选
			};
		},
		btnShare: function () {
			// 显示分享按钮
			wx.showShareMenu({
				withShareTicket: true
			});
		}
})