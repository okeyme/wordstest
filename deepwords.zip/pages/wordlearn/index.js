// pages/wordlearn/index.js
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
			headerName:'单词训练',
			scrollHeight: 1000,
			scrollTop: 0
		},
		goWordNote: function(){
			app.gotoPage("/pages/wordlearn/wordnote");
		},
		golineDictate: function(){
			app.gotoPage("/pages/category/index?classid=1");
		},
		goautoDictate: function(){
			app.gotoPage("/pages/category/index?classid=2");
		},
		gowordText: function(){
			app.gotoPage("/pages/category/index?classid=3");
		},
		gowordSpell: function(){
			app.gotoPage("/pages/category/index?classid=4");
		},
		gowordListen: function(){
			app.gotoPage("/pages/category/index?classid=5");
		},
		gotranslateWord: function(){
			app.gotoPage("/pages/category/index?classid=6");
		},	
		gotranslateSpell: function(){
			app.gotoPage("/pages/category/index?classid=7");
		},
		gotranslateListen: function(){
			app.gotoPage("/pages/category/index?classid=8");
		},
		golistenWord: function(){
			app.gotoPage("/pages/category/index?classid=9");
		},
		golistenSpell: function(){
			app.gotoPage("/pages/category/index?classid=10");
		},
		golistenTranslate: function(){
			app.gotoPage("/pages/category/index?classid=11");
		},
		goBack: function() {
			app.gotoBack();
		},
		goHome: function() {
			app.gotoHome();
		},
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
			var that = this;
			const windowInfo = wx.getWindowInfo()
			const query = wx.createSelectorQuery();
			query.select('.header').boundingClientRect(data => {
				if (data) {
					let sHeight = windowInfo.windowHeight - data.height;
					that.setData({scrollTop:data.height, scrollHeight: sHeight});
				}
			}).exec();
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})