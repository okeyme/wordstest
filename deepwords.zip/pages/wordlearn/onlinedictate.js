// pages/wordlearn/onlinedictate.js
const app = getApp();
const wxc = app.globalData.wxc;
const webAudio = wx.createInnerAudioContext({
	useWebAudioImplement: true
});
const util = require('../../utils/util.js');
var timer = null;
Page({

    /**
     * 页面的初始数据
     */
    data: {
			headerName: '在线听写',
			serverHost: 'https://bossbell.com/miniprogram/',
			scrollHeight: '200px',
			scrollTop: 0,
			cid:null,
			wordCurrect:0,
			wordCount:0,
			CorrectCount:0,
			dataArr:'',
			Wordlist:[],
			wordArr:[],
			letters:[],
			webAudioStatus:false,
			translate: '',
			showTranslate: false,
			myEnterWord: '',
			wordCapital: false,
			clickLetter: '',
			timerCount:6,
			buttonTxt: '下一个',
			correctStatus:-1,
			showResult: false,
			errorWordArr:[],
			activeItem:0,
			check:false,
			timestamp: new Date().getTime(),
			mytimestamp:'--分-秒'
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
			this.data.cid = options.cid;
			var that = this;
			const TokenStatus = setInterval(()=>{
				if(app.globalData.token!=''){
					clearInterval(TokenStatus);
					that.checkWordlist();
				}
			},100)
		},
		playAudio: function(){
			this.audioPlay();
		},
		wordAudio: function(e){
			let index = e.currentTarget.dataset.index;
			this.data.wordCurrect = index;
			let word_id = this.data.wordArr[this.data.wordCurrect].word_id;
			this.audioPlay();
			this.setData({ activeItem: word_id});
		},
		audioPlay: function () {
			var that = this;
			let src = this.data.wordArr[this.data.wordCurrect].audio;
			let word_id =  this.data.wordArr[this.data.wordCurrect].word_id;
      webAudio.src = src;
			webAudio.play();
			that.setData({ webAudioStatus: true});
      webAudio.onPlay(()=>{
				console.log('音频开始播放');
      })
      webAudio.onEnded(()=>{
				console.log('音频播放完毕');
				that.setData({ activeItem:0,webAudioStatus: false});
      })
		},
		showTranslate: function(){
			this.setData({ showTranslate: !this.data.showTranslate});
		},
		deleteLetter: function(){
			var letterWord = this.data.myEnterWord;
			if(letterWord.length>0){
				letterWord = letterWord.substring(0, letterWord.length-1);
				this.setData({ myEnterWord: letterWord});
			}
		},
		handleTouchStart: function(e){
			clearTimeout(timer);
			var that = this;
			var obj = e.currentTarget.dataset;
			var letter = obj.letter;
			var letterWord = this.data.myEnterWord;
			if(letter=='大写'){
				this.setData({ wordCapital: !this.data.wordCapital});
			}else if(letter=='句点'){
				letterWord=letterWord+'.';
			}else if(letter=='中横'){
				letterWord=letterWord+'-';
			}else if(letter=='上撇'){
				letterWord=letterWord+"'";
			}else if(letter=='空格'){
				letterWord=letterWord+' ';
			}else{
				if(this.data.wordCapital){
					letter = letter.toUpperCase();
					this.setData({ wordCapital: !this.data.wordCapital});
				}
				letterWord = letterWord+letter;
			}
			if(letter!='大写'){
				this.setData({ myEnterWord: letterWord,clickLetter:letter});
			}
		},
		handleTouchEnd: function(){
			this.timer = setTimeout(() => {
				this.setData({ clickLetter: ''});
			},500);
		},
		check: function(){
				clearInterval(timer); 
				var that = this;
				var wordArr = this.data.wordArr;
				var errorWordArr = this.data.errorWordArr;
				let wordCurrect = this.data.wordCurrect;
				console.log('check-wordCurrect='+wordCurrect);
				let correctWord = wordArr[wordCurrect].word;
				console.log(correctWord+'='+this.data.myEnterWord);
				if(correctWord==this.data.myEnterWord){
					that.setData({check:true,translate:'正确', showTranslate:true,CorrectCount:that.data.CorrectCount+1,correctStatus:1});
					webAudio.src="https://bossbell.com/speak/mp3/star4.mp3";
					webAudio.play()
				}else{
					that.setData({check:true,translate:'正确答案：'+wordArr[wordCurrect].word, showTranslate:true,correctStatus:0});
					errorWordArr[wordCurrect] = this.data.myEnterWord; //记录错误答案
					webAudio.src="https://bossbell.com/speak/mp3/star1.mp3";
					webAudio.play()
				}
				timer = setInterval(() => {
					if(that.data.timerCount==1){
						this.nextWord();
					}else{
						that.data.timerCount = that.data.timerCount-1;
						that.setData({ buttonTxt:'('+that.data.timerCount+')下一个'});
					}
				},1000)
		},
		nextWord: function(){
			clearInterval(timer); 
			let wordCurrect = this.data.wordCurrect;
			if(wordCurrect+1==this.data.wordCount){
				this.showResult();
			}else{
				wordCurrect = wordCurrect+1;
				let nowtime = new Date().getTime();
				//let mytimestamp = nowtime - this.data.timestamp;
				let mytimestamp = this.timestampToTime(this.data.timestamp,nowtime);
				this.setData({check:false,wordCurrect:wordCurrect,buttonTxt:'下一个',showTranslate:false,timerCount:6,myEnterWord:'',correctStatus:-1,mytimestamp:mytimestamp});
				this.showWord();
			}
		},
		showWord: function(){
			var that = this;
			var wordArr = this.data.wordArr;
			let wordCurrect = this.data.wordCurrect;
			console.log('show-wordCurrect='+wordCurrect);
			let word = wordArr[wordCurrect].word;
			word = word.replace(/\s*/g,''); 
			let wordLetters = word.split(''); //打散为字母
			wordLetters = wordLetters.map(function(item) {
				return item.toLowerCase();
			});
			var LettersArr = Array.from(new Set(wordLetters));  //去重
			console.log(LettersArr);
			var abcArr=['b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'];
			var fixabc=['a','e','i','u','o'];
			var LettersArr2 = LettersArr.filter(item => !fixabc.includes(item)); //取差集
			//console.log(LettersArr2);
			var letters = LettersArr2;
			let LetterCount = LettersArr2.length;
			if(LetterCount<10){
				var abcArr2 = abcArr.filter(item => !LettersArr2.includes(item)); //取差集
			//	console.log(abcArr2);
				let addAbcArr = this.getRandomElements(abcArr2,10-LetterCount);
				var LettersArr3 = LettersArr2.concat(addAbcArr);
				letters = LettersArr3;
			}
			letters = this.shuffleArray(letters); //打乱
			that.setData({letters:letters,translate:wordArr[wordCurrect].translate});
			this.audioPlay();
		},
		timestampToTime: function(timestamp1,timestamp2){
			var date1 = new Date(timestamp1);
			var date2 = new Date(timestamp2);
		
			// 计算时间差（毫秒）
			var difference = date2 - date1;
		
			// 考虑时区偏差
			var timeZoneOffset1 = date1.getTimezoneOffset() * 60000; // 转换为毫秒
			var timeZoneOffset2 = date2.getTimezoneOffset() * 60000; // 转换为毫秒
		
			// 调整时间差以考虑时区偏差
			var adjustedDifference = difference + timeZoneOffset1 - timeZoneOffset2;
		
			// 将时间差转换为小时和分钟
			var hours = Math.floor(adjustedDifference / 3600000);
			var minutes = Math.floor((adjustedDifference % 3600000) / 60000);
			var seconds = Math.floor(adjustedDifference / 1000);
			return minutes + "分" + seconds+'秒';
		},
		selectWordlist: function(){
			var that = this;
			var Wordlist = this.data.Wordlist;
			console.log('Wordlist',Wordlist);
			let cid = this.data.cid;
			console.log('cid',cid);
			if(Wordlist.hasOwnProperty(cid)) {
				var cateArr = Wordlist[cid]; //当前单元
				let idlist = cateArr['idlist'];
				if(idlist=='') return;
				let idlistarr = idlist.split(",");
				//随机取10个
				var cc = 10;
				if(idlistarr.length>=10){
					cc = 10;
				}else{
					cc = idlistarr.length;
				}
				var keyarr = util.getRandomElements(idlistarr,cc);
				console.log('keyarr',keyarr);
				var arr = [],errorWordArr = [];
				for(let key in keyarr){
					errorWordArr.push('');
					let obj = Wordlist['list'][keyarr[key]];
					let translate = obj.translate;
					translate = translate.replace(/\|/g, " ");
					translate = translate.replace(/#/g, " ");
					obj.translate = translate;
					let audio = obj.audio;
					if(audio.indexOf('uploads/phonogram')>=0){
						audio = audio.replace('uploads','https://w.360e.cn/uploads/english');
					}else{
						audio = 'https://bossbell.com/'+audio;
					}
					obj.audio = audio;
					arr.push(obj);
				}
				//this.data.wordKeyList = wordKeyList;
				console.log('arr',arr);
				that.setData({wordArr:arr,errorWordArr:errorWordArr,wordCount:cc});
				that.showWord();
			}
		},
		shuffleArray:function(array){
			array.sort(() => Math.random() - 0.5);
  		return array;
		},
		getRandomElements: function(arr, count) {
			const shuffled = [...arr].sort(() => 0.5 - Math.random());
  		return shuffled.slice(0, count);
		},
		showResult: function(){
			let errorWordArr = this.data.errorWordArr;
			this.setData({errorWordArr:errorWordArr, showResult:true});
		},
		checkWordlist: function(){
			var that = this;
		//查有没有缓存 token, 缓存可能被清空
			wxc.get('Wordlist').then(res=>{
				let dataArr = res;
				console.log('dataArr',dataArr);
				that.data.dataArr = dataArr;
				that.getWordlist(dataArr.version);
			}).catch(err=>{
				that.getWordlist();
			});
		},
		getWordlist: function(versionNumber=''){
			var that = this;
			app.requestHttp({ac:'getallwordlist',vg_id:app.globalData.vg_id,versionNumber:versionNumber}).then(res=>{
				console.log('res',res);
				if (res.data.code == 20000){
					var dataArr = that.data.dataArr;
					that.data.Wordlist = dataArr.data;
					that.selectWordlist();
				}else if(res.data.code == 10000){
					let dataArr = res.data.data;
					wxc.set('Wordlist',dataArr);
					that.data.Wordlist = dataArr.data;
					that.selectWordlist();
				} else {
					console.log("Wordlist获取失败");
				}
				/*if (res.data.code == 20000 || res.data.code == 10000) {
					if(res.data.code == 10000){
						let arr = res.data.data.data;
					}else{
						let arr = that.data.dataArr.data;
					}
					that.setData({Wordlist:arr});
					that.selectWordlist();
				} else {
					console.log("Wordlist获取失败");
				}*/
			}).catch(err=>{
				app.showError('Wordlist获取失败');
			});
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
			var that = this;
			const windowInfo = wx.getWindowInfo()
			const query = wx.createSelectorQuery();
			query.select('.header').boundingClientRect(data => {
				if (data) {
					let sHeight = windowInfo.windowHeight - data.height;
					that.setData({scrollTop:data.height, scrollHeight:sHeight});
				}
			}).exec();
    },
		goBack: function() {
			app.gotoBack();
		},
		goHome: function() {
			app.gotoHome();
		},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})