// pages/wordlearn/autodictate.js
const app = getApp();
const wxc = app.globalData.wxc;
const backgroundAudioManager = wx.getBackgroundAudioManager();
const webAudio = wx.createInnerAudioContext({
	useWebAudioImplement: true
});
var timer = null;
Page({
    /**
     * 页面的初始数据
     */
    data: {
			headerName: '自助听写',
			serverHost: 'https://bossbell.com/miniprogram/',
			scrollHeight: '200px',
			scrollTop: 0,
			dataArr:'',
			cid:null,
			Wordlist:[],
			showList: [],
			oldshowList:[],
			audioIndex: -1,
			autoDictate: false,
			webAudioStatus: false,
			backgroundAudioStatus: 0, //0默认，1播放，2暂停
			order: true,
			autoTime: 3,
			timestep:[3,6,9,12,15],
			timevalue:[0],
			pickerShow: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
			this.data.cid = options.cid;
			var that = this;
			const TokenStatus = setInterval(()=>{
				if(app.globalData.userVersion!=''){
					clearInterval(TokenStatus);
					that.checkWordlist();
				}
			},100)
		},
		playAudio: function(){
			this.audioPlay();
		},
		wordAudio: function(e){
			if(this.data.backgroundAudioStatus>0){
				app.showToast('正在自动播报，无法点播。');
				return;
			}
			let index = e.currentTarget.dataset.index;
			this.data.audioIndex = index;
			this.audioPlay();
		},
		audioPlay: function () {
			var that = this;
			let audioIndex = this.data.audioIndex;
			var showList = this.data.showList;
			let src = showList[audioIndex].audio;
      webAudio.src = src;
			webAudio.play();
			that.setData({ audioIndex:audioIndex, webAudioStatus: true});
      webAudio.onPlay(()=>{
				console.log('音频开始播放');
      })
      webAudio.onEnded(()=>{
				console.log('音频播放完毕');
				that.setData({ webAudioStatus: false});
      })
		},
		autoDictate: function(){
			if(this.data.backgroundAudioStatus==1){  //暂停
				console.log('执行1');
				clearTimeout(timer);
				this.backgroundAudioManagerPause();
			}else if(this.data.backgroundAudioStatus==2){ //暂停后再播放
				console.log('执行2');
				this.backgroundAudioManagerAuto();
			}else{  //弹出选择时间间隔
				console.log('执行0');
				this.setData({pickerShow: !this.data.pickerShow});
			}
		},
		onChange: function(e){
			// 获取当前选中的值的索引
			let index = e.detail.value;
			// 根据索引获取对应的列表项
			this.data.autoTime = this.data.timestep[index];
		},
		startAuto: function(){
			this.setData({audioIndex:0, autoDictate: true, pickerShow: false});
			this.backgroundAudioManagerAuto();
		},
		backgroundAudioManagerPause: function(){
			var that = this;
			backgroundAudioManager.pause();
			backgroundAudioManager.onPause(()=>{
				//执行
			}); 
			that.setData({backgroundAudioStatus: 2,webAudioStatus:false});
		},
		backgroundAudioManagerAuto: function(){
			var that = this;
			if(that.data.webAudioStatus){
				webAudio.stop();
				that.data.webAudioStatus = false;
			}
			if(this.data.backgroundAudioStatus==0){
				wx.showToast({
					title: '加载音频...',
					icon: 'loading',
					duration: 2000
				})
			}
			this.backgroundAudioManagerPlay();
		},
		backgroundAudioManagerPlay: function(){
			clearTimeout(timer);
			var that = this;
			var audioIndex = this.data.audioIndex;
			var obj = this.data.showList[audioIndex];
			backgroundAudioManager.title = obj.word;
			backgroundAudioManager.singer = obj.translate;
			backgroundAudioManager.src = obj.audio;
			let coverImage = obj.translate_pic;	
			backgroundAudioManager.coverImgUrl = coverImage;

			that.setData({ audioIndex: audioIndex, webAudioStatus: true,backgroundAudioStatus: 1});
			// 播放模式设置为列表循环
			backgroundAudioManager.onPlay(() => {
				// 当播放开始时，可以处理一些逻辑
				wx.hideToast();
			});
			backgroundAudioManager.onError((res) => {
				// 当播放出错时，可以处理一些逻辑
				//that.data.audioIndex = that.data.audioIndex+1;
				that.setData({backgroundAudioStatus: 2,webAudioStatus:false});
			});
			backgroundAudioManager.onStop(() => {
				// 当播放停止时，可以处理一些逻辑
				that.setData({backgroundAudioStatus: 2,webAudioStatus:false});
			});
			backgroundAudioManager.onEnded(() => {
				if(that.data.autoDictate){
					that.setData({webAudioStatus: false});
					that.backgroundAudioManagerNext();
				}
			});
			// 音频播放错误监听
			backgroundAudioManager.onError((err) => {
				console.error(err);
				that.data.audioIndex = that.data.audioIndex+1;
				// 错误处理逻辑
			});
			backgroundAudioManager.play();
		},
		backgroundAudioManagerNext: function(){
			var that = this;
			let autoTime = this.data.autoTime;
			autoTime = autoTime*1000;
			console.log('autoTime='+autoTime);
			this.data.audioIndex = this.data.audioIndex+1;
			if(this.data.audioIndex<this.data.showList.length){
				timer = setTimeout(function() {
					that.backgroundAudioManagerPlay();
					//clearTimeout(timer);
				},autoTime)
			}else{
				setTimeout(function(){
					that.playxiaoe();
				},autoTime);
				that.setData({audioIndex: -1, autoDictate: false, backgroundAudioStatus:0});
			}
		},
		playxiaoe: function(){
			backgroundAudioManager.title = '播报结束';
			backgroundAudioManager.singer = '当前列表已播完';
			backgroundAudioManager.src = 'https://bossbell.com/public/eplay.mp3';
			backgroundAudioManager.coverImgUrl = 'http://bossbell.com/public/images/slogo.jpg';
			backgroundAudioManager.play();
		},
		Order: function(){
			if(this.data.backgroundAudioStatus>0){
				app.showToast('正在自动播报，无法操作排序。');
				return;
			}
			let order = !this.data.order;
			var showList = this.data.showList;
			var wordlistkeys = Object.keys(showList);
			let keys = [], newArr = [];
			if(order){
				newArr = this.data.oldshowList;
			}else{
				keys = this.shuffleArray(wordlistkeys); 
				for(let key in keys){
					newArr[key] = showList[keys[key]];
				}
			}
			this.setData({showList:newArr, order:order});
		},
		shuffleArray:function(array){
			array.sort(() => Math.random() - 0.5);
  		return array;
		},
		filterWorList: function(){
			var that = this;
			var Wordlist = this.data.Wordlist;
			let cid = this.data.cid;
			if (Wordlist.hasOwnProperty(cid)) {
				var cateArr = Wordlist[cid]; //当前单元
				console.log('cateArr',cateArr);
				this.data.cateArr = cateArr;
				let idlist = cateArr['idlist'];
				if(idlist=='') return;
				let idlistarr = idlist.split(",");
				var arr = [];
				for(let key in idlistarr){
					let obj = Wordlist['list'][idlistarr[key]];
					console.log('obj',obj);
					arr[key] = obj;
					let translate = obj.translate;
					translate = translate.replace(/\([^\)]*\)/g, "");
					translate = translate.replace(/（[^\）]*）/g, "");
					arr[key]['translate'] = translate;
					let pic = obj.translate_pic;
					if(pic==''){
								pic = 'http://www.quword.com/images/words/'+obj.word+'1.jpg';
					}else{
								pic = pic.replace("https:","http:");
					}
					arr[key]['translate_pic'] = pic;
					let audio = obj.audio;
					if(audio.indexOf('uploads/phonogram')>=0){
						audio = audio.replace('uploads','https://w.360e.cn/uploads/english');
					}else{
						audio = 'https://bossbell.com/'+audio;
					}
					arr[key]['audio'] = audio;
				}
				console.log('arr',arr);
				that.data.oldshowList = arr;
				that.setData({showList:arr});
			}
		},
		checkWordlist: function(){
			var that = this;
		//查有没有缓存 token, 缓存可能被清空
			wxc.get('Wordlist').then(res=>{
				let dataArr = res;
				that.data.dataArr = dataArr;
				console.log('dataArr',dataArr);
				let versionNumber = dataArr.version;
				that.getWordlist(versionNumber);
			}).catch(err=>{
				that.getWordlist();
			})
		},
		getWordlist: function(versionNumber=''){
			var that = this;
			console.log('==getallwordlist 开始==');
			app.requestHttp({ac:'getallwordlist',vg_id: app.globalData.vg_id,versionNumber:versionNumber}).then(res=>{
				console.log('res=',res);
				if(res.data.code==20000){
					var dataArr = that.data.dataArr;
					that.setData({Wordlist:dataArr.data});
					console.log(that.data.Wordlist);
					that.filterWorList();
				}else if(res.data.code==10000){
					var dataArr = res.data.data;
					wxc.set('Wordlist',dataArr);
					that.setData({Wordlist:dataArr.data});
					console.log(that.data.Wordlist);
					that.filterWorList();
				}
			}).catch(err=>{
				app.showError('数据获取失败');
			});
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
			var that = this;
			const windowInfo = wx.getWindowInfo()
			const query = wx.createSelectorQuery();
			query.select('.header').boundingClientRect(data => {
				if (data) {
					let sHeight = windowInfo.windowHeight - data.height;
					that.setData({scrollTop:data.height});
				}
			}).exec();
			query.select('.foot').boundingClientRect(data => {
				if (data) {
					let sHeight = windowInfo.windowHeight - this.data.scrollTop - data.height;
					that.setData({scrollHeight:sHeight});
				}
			}).exec();
    },

    /**
     * 生命周期函数--监听页面显示
     */
		goBack: function() {
			app.gotoBack();
		},
		goHome: function() {
			app.gotoHome();
		},
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})