const app = getApp();
import wordDataManager from '../../utils/wordDataManager';
/*const audioContext = wx.createInnerAudioContext({
	useWebAudioImplement: true
});*/
const CACHE_KEY = 'wordlistData';

Page({

	/**
	 * 页面的初始数据
	 */
	data: {
    timer: null, 
		isPlaying: false,// 是否正在播放
		playCount: 0,           // 当前单词已播放次数
		showWord:true,  
		showTranslate: true,
		audioContext:null,
		backgroundAudioStatus: false,
		currentIndex: -1,
		//弹窗数据
		unitId:0,
		list:[],
		vgId:0,
		loading: false,
		localVersion: 0,
		unitList:[],
		list: [],
		list_clone:[],
		catelist:[],
		scrollLeft: 0,
		orderOptions:['顺序','乱序'],
		orderIndex:0,
		timeOptions:[5,8,10,12],
		timeIndex:0
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad(options) {
		var unitId = options.unitId;
		this.setData({
			vgId: app.globalData.userVersion.vg_id,
			unitId: unitId,
			audioContext : wx.createInnerAudioContext()
		},()=>{
			this.initTraining(this.data.unitId);
		})

		// 监听音频播放结束事件
    this.data.audioContext.onEnded(() => {
			console.log('当前单词播放结束');
			this.handleAudioEnd();
      // 如果需要在每个单词播放结束后立即切换到下一个，可以在这里调用
      // this.nextWord();
    });
    
    // 监听错误
    this.data.audioContext.onError((err) => {
      console.error('音频播放错误:', err);
      wx.showToast({
        title: '播放失败，请重试',
        icon: 'none'
      });
		});
		
	},
	// 初始化单词数据
  async initTraining(unitId) {
		let unitIdArray = unitId.split(",").map(Number); 
    this.setData({ 
      isLoading: true 
		});
    try {
      // 1. 直接获取所有选中单元的单词
      const allWords = await wordDataManager.getTrainingWordList(
        this.data.vgId, 
        unitIdArray, 
        { 
          wordCount: 0, // 0表示不限制数量，获取所有单词
          shuffle: false // 先不打乱，保持单元顺序
        }
			);
			console.log('===allWords===',allWords);
      
      if (allWords.length === 0) {
        wx.showToast({ title: '没有找到单词', icon: 'none' });
        return;
      }

      this.setData({ 
				list: allWords,
				list_clone: allWords,
        isLoading: false 
      });

      // 2. 开始训练会话
      //this.loadWord();
    } catch (error) {
      console.error('训练初始化失败:', error);
      this.setData({ isLoading: false });
    }
  },
	// 开始播放单词
	startPlay() {
		if (this.data.isPlaying) {
			this.pausePlay();
		}else{
			this.setData({ isPlaying: true });
			this.playCurrentWord();
		}
	},

	// 播放当前单词
	playCurrentWord() {
		var list = this.data.list;
		if(this.data.currentIndex==-1) {
			this.setData({
				currentIndex: 0
			});
		}
		var currentWord = list[this.data.currentIndex];
		if (!currentWord) return;
		const audioContext = this.data.audioContext;
		audioContext.src = currentWord.audio; // 设置音频源
		audioContext.play(); // 播放
	},
	// 处理音频播放结束
	handleAudioEnd() {
		const { playCount } = this.data;
		
		// 如果当前单词播放次数小于2次，则再次播放
		if (playCount < 1) {
			this.setData({
				playCount: playCount + 1
			});
			this.playCurrentWord();
		} else {
			// 否则切换到下一个单词
			this.nextWord();
		}
	},
	// 切换到下一个单词
	nextWord() {
		const { list, currentIndex } = this.data;
		const nextIndex = (currentIndex + 1) % list.length;
		if(nextIndex==0){
			this.resetPlay(); return;
		}

		this.setData({ 
			currentIndex: nextIndex,
			playCount: 0 // 重置播放次数
		 });
		// 延迟5秒后播放下一个单词
		let timeset = this.data.timeOptions[this.data.timeIndex];
    this.data.timer = setTimeout(() => {
      if (this.data.isPlaying) {
        this.playCurrentWord();
      }
    }, timeset*1000);
		
	},
	playThisWord(e){
		const index = e.currentTarget.dataset.index;
		this.setData({ 
			currentIndex: index,
			playCount: 0 // 重置播放次数
		});
		this.playCurrentWord();
	},
	// 暂停播放
	pausePlay() {
		if (!this.data.isPlaying) return;
		
		this.setData({ isPlaying: false });
		clearInterval(this.data.timer);
		this.data.audioContext.pause();
	},

	// 重置播放
	resetPlay() {
		this.pausePlay();
		this.setData({ currentIndex: -1 ,playCount: 0});
	},

	// 页面卸载时清理资源
	onUnload() {
		this.pausePlay();
		if(this.data.audioContext) this.data.audioContext.destroy();
	},
	changeOrder:function(){
		const {list,orderIndex,list_clone} = this.data;
		if(orderIndex==1){
			var shuffled = [...list];
			// Fisher-Yates 洗牌算法
			for (let i = shuffled.length - 1; i > 0; i--) {
				// 生成 0 到 i 之间的随机索引
				const j = Math.floor(Math.random() * (i + 1));
				// 使用解构赋值交换元素
				[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
			}
		}else{
			var shuffled = list_clone;
		}
		this.setData({ list: shuffled,isPlaying:false,currentIndex:0});
	},
	onOrderChange(e){
		if (this.data.isPlaying) { app.showToast('请暂停后再操作'); return;}
		let orderIndex = e.detail.value;
		if(orderIndex==this.data.orderIndex) return;
		this.setData({ orderIndex:  orderIndex},()=>{
			this.changeOrder();
		});
		
	},
	onTimeChange(e){
		this.setData({ timeIndex: e.detail.value });
	},
	gowordWrite:function(){
		var checkval = this.data.checkval;
		let valstr = checkval.join(",");
		let url = "/pages/wordlist/wordwrite?unitId="+this.data.currentTab+"&list="+valstr;
		app.gotoPage(url);
	},
	gowordLearn:function(){
		let url = "/pages/wordlist/wordlearn?unitId="+this.data.currentTab;
		app.gotoPage(url);
	},
	goBack: function() {
		app.gotoBack();
	},
	goHome: function() {
		app.gotoHome();
	},
	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow() {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide() {

	},
	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady() {

	},
	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload() {
		this.data.audioContext.stop();
		this.data.audioContext.destroy();
		this.data.isPlaying = false;
	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh() {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom() {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage() {

	}
})